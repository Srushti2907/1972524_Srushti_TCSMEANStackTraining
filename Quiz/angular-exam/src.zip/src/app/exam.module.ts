export class Exam{
     constructor(public id:number,public question:string,public a:string,public b:string,public c:string,public d:string,public answer:string
        ,public selected ?: string){}
    

}